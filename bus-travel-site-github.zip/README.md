
# SwiftRide — Bus Travel Website (GitHub Pages)

A professional, static website for a bus travel company. Built with HTML, CSS, and vanilla JS; ready to deploy on **GitHub Pages**.

## 🚀 Quick Start

1. **Create a new repository** on GitHub (e.g., `swiftride`).
2. **Upload** these files to the root of the repo.
3. In your repo: **Settings → Pages → Build and deployment**  
   - *Source*: `Deploy from a branch`  
   - *Branch*: `main` and `/root`
4. Save. Your site will be live at:  
   `https://<your-username>.github.io/<repo-name>/`

> This template includes a `404.html` and `.nojekyll` for smooth GitHub Pages hosting.

## 🧰 Customize

- Update routes in `routes.json`.
- Replace hero image URL in `styles.css` and the Open Graph image at `assets/og-cover.jpg`.
- Swap the favicon at `assets/favicon.svg`.
- Change brand name, copy, and contact email in `index.html`.

### Booking & Contact Forms (Static)

GitHub Pages is static, so you’ll need a third‑party form backend:
- [Formspree](https://formspree.io/) or [FormSubmit](https://formsubmit.co/)
- Replace the `action="#"` in `<form>` with your endpoint.

### Local Preview

Just open `index.html` in your browser. For fetches (like `routes.json`) to work locally, run a tiny server:

```bash
# Python 3
python -m http.server 8000
# visit http://localhost:8000
```

## 📂 Structure

```
/
├─ index.html
├─ styles.css
├─ script.js
├─ routes.json
├─ privacy.html
├─ terms.html
├─ 404.html
├─ manifest.webmanifest
├─ .nojekyll
└─ assets/
   ├─ favicon.svg
   └─ og-cover.jpg
```

## 📝 License

MIT — use freely, attribution appreciated.
