// Basic interactivity for SwiftRide (static GitHub Pages site)
/* global fetch */
const navToggle = document.getElementById('navToggle');
const siteNav = document.getElementById('siteNav');
if (navToggle && siteNav) {
  navToggle.addEventListener('click', () => {
    const open = siteNav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(open));
  });
}

// Load routes from routes.json and render cards
async function loadRoutes() {
  try {
    const res = await fetch('routes.json', { cache: 'no-store' });
    const routes = await res.json();
    const list = document.getElementById('routesList');
    if (!list) return;
    list.innerHTML = '';
    routes.forEach(r => {
      const el = document.createElement('article');
      el.className = 'route';
      el.innerHTML = \`<h4>\${r.from} → \${r.to}</h4>
        <p><strong>Times:</strong> \${r.times.join(', ')}</p>
        <p><strong>Duration:</strong> \${r.duration}</p>
        <p><strong>Fare:</strong> ₹\${r.fare}</p>\`;
      list.appendChild(el);
    });
  } catch (e) {
    console.error('Failed to load routes', e);
  }
}
loadRoutes();

// Demo search handling (client-side filter)
const bookingForm = document.getElementById('bookingForm');
const results = document.getElementById('searchResults');
if (bookingForm && results) {
  bookingForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = new FormData(bookingForm);
    const from = String(data.get('fromCity') || '').toLowerCase();
    const to = String(data.get('toCity') || '').toLowerCase();

    try {
      const res = await fetch('routes.json', { cache: 'no-store' });
      const routes = await res.json();
      const matches = routes.filter(r =>
        r.from.toLowerCase().includes(from) && r.to.toLowerCase().includes(to)
      );
      results.innerHTML = matches.length
        ? matches.map(m => \`<div class="result-card">
            <h4>\${m.from} → \${m.to}</h4>
            <p><strong>Next departures:</strong> \${m.times.slice(0,3).join(', ')}</p>
            <p><strong>Fare:</strong> ₹\${m.fare} • <strong>Duration:</strong> \${m.duration}</p>
            <button class="btn btn-primary" onclick="alert('Proceed to payment flow (backend needed).')">Book</button>
          </div>\`).join('')
        : '<p>No buses found for your search. Try different cities.</p>';
    } catch (err) {
      results.textContent = 'Could not search at the moment.';
    }
  });
}
